=======================================
Contributing to the Facebook Python SDK
=======================================

See `the "Contributing" section of the package's documentation`_ for details on
submitting pull requests, code style, and more.

.. _the "Contributing" section of the package's documentation: https://facebook-sdk.readthedocs.org/en/latest/support.html#contributing
